The following is my rough estimate of how "complete" each area is. I adjust numbers up as work is completed (or deemed unnecessary) and down as the list of work items grows.

|| Read || Write ||
| [PST Layer](pst_read_issues) 99% | PST Layer 0 % |
| LTP Layer 99% | LTP Layer 0 % |
| [NDB Layer](ndb_read_issues) 99% | [NDB Layer](ndb_write_issues) 20% |
| Disk Layer 99% | Disk Layer N/A |
| [Util Layer](util_read_issues) 99% | Util Layer N/A |

| [Test](test_issues) 85% |

| [Cross Platform Support](cross_platform_issues) 90% |

| Sample Programs 75% |

| [Documentation](documentation_issues) 99% |

Terry is currently working on: Bug fixes, processing feedback from first beta