## NDB Read Issues

Add an iterator adaptor so we can iterate over nodes, subnodes