## Test Issues

What is there currently is better than nothing. I wish it were better structured and more formalized, perhaps using Boost::Unit