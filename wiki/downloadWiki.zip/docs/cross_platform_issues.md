## Cross Platform Issues

Working once again. At least GCC 4.4.1 on Windows (MinGW). Ideally I'd like to validate it works truly cross platform.

I've heard that it compiles in GCC 4.3 on Linux and GCC 4.2 on MacOSX, but the unit tests do not pass.