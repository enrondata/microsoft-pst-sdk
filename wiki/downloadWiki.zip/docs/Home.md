**Project Description**
PST File Format SDK (pstsdk) is a cross platform header only C++ library for reading PST files.

[Quick Start Guide For Developers](quick_start_devs) (for developers working on PST File Format SDK)
[Quick Start Guide For Users](quick_start_users) (for developers _using_ PST File Format SDK in other projects)

[Project Status](Project-Status)